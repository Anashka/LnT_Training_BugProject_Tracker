import { Component } from "@angular/core";
import { Project } from "./models/Project";
import { ProjectOperationsService } from './services/projectOperation.service';


@Component({
    selector : 'app-project-tracker',
    templateUrl: './projectTracker.component.html'
})
export class ProjectTrackerComponent{
    projects: Project[] = [];
    

    sortAttr : string = '';
    sortDesc : boolean = false;

    constructor(private projectOperations : ProjectOperationsService){
        this.projectOperations
            .getAll()
            .subscribe(projects => this.projects = projects);
    }


    onNewProjectCreated(newProject : Project){
        this.projects = [...this.projects, newProject];
    }

    onRemoveClick(projectToRemove: Project){
        this.projectOperations
            .remove(projectToRemove)
            .subscribe(() => this.projects = this.projects.filter(project => project !== projectToRemove))
        
    }

   

}