import { ProjectOperationsService } from "../services/projectOperation.service";

import { Component, Output, EventEmitter } from "@angular/core";
import { Project } from "../models/Project";


@Component({
    selector : 'app-project-edit',
    template : `
        <section class="edit">
            <label for="">Project Name :</label>
            <input type="text" (input)="newProjectName=$event.target.value">
            <input type="button" value="Add new" (click)="onAddNewClick()">
        </section>
    `
})
export class ProjectEditComponent{

    newProjectName: string = '';

    @Output()
    projectCreated : EventEmitter<Project> = new EventEmitter<Project>();

    constructor(private bugOperations : ProjectOperationsService ){

    }

    onAddNewClick() {
        this.bugOperations
            .createNew(this.newProjectName)
            .subscribe(newProject => this.projectCreated.emit(newProject));
        //the following line should be in the parent component
        //this.bugs = [...this.bugs, newBug];
    }
}