import { Project } from "../models/Project";
import { Injectable } from '@angular/core';
import { ProjectApiService } from "./projectApi.service";
import { Observable } from "rxjs";

@Injectable()
export class ProjectOperationsService{
    constructor(private projectApi: ProjectApiService) {

    }
    createNew(projectName: string): Observable<Project> {
        const newProject = {
            id: 0,
            name: projectName
        };
        return this.projectApi.savePro(newProject);
        
    }


    getAll(): Observable<Project[]> {
        return this.projectApi.getAllPro();
    }

    remove(project: Project) : Observable<any> {
        return this.projectApi.removePro(project);
    }
}